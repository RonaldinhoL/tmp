import base64

import js2py
import quickjs
import v8py


class V1:

    def __init__(self):
        self._js_decrypt_flow_resp = None
        # self.ctx = js2py.EvalJs()
        # self.ctx = quickjs.Context()
        self.ctx = v8py.Context(self)
        # self.ctx.add_callable("atob", self.atob)
        # self.ctx.add_callable("print", print)
        self.ctx["atob"] = self.atob
        self.ctx["print"] = print

    def print(self, *args):
        print(*args)

    def atob(self, s):
        return base64.b64decode(s)

    def decrypt_flow_resp(self, cRay, resp):
        if not self._js_decrypt_flow_resp:
            self._js_decrypt_flow_resp = self.ctx.eval("""
                function f(resp, ray_0, H, G, F, E, D) {
                    try{
                        E = 32;
                        ray_0 = ray_0["replace"](/./g, function (I, J) {
                            E ^= ray_0["charCodeAt"](J);
                        });
                        resp = atob(resp)
                        G = [];
                        for (H = -1; !isNaN(D = resp[++H]); G["push"](String["fromCharCode"](((D & 255) - E - H % 65535 + 65535) % 255))) {
                            ;
                        }
    
                        return G["join"]("");
                    } catch (e) {
                        print(e.toString())
                        print(e.stack)
                    }
                };
            """)
        # return self.ctx.get("f")(resp, cRay + "_0")
        return self.ctx.eval('f')(resp, cRay + "_0")
