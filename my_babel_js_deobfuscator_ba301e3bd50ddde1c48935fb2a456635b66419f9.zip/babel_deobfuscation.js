// cnpm install --save-dev @babel/core @babel/parser @babel/traverse @babel/generator @babel/types @babel/generator @babel/template

const path = require("path");

const parser = require("@babel/parser")
const traverse = require("@babel/traverse").default
const t = require("@babel/types")
const generator = require("@babel/generator").default
const template = require("@babel/template").default;

// const {promises: {readFile, writeFile}} = require('fs')
const fs = require('fs')
const {isBooleanLiteral, functionDeclaration, binaryExpression, callExpression} = require("@babel/types");

// const fs = require('fs/promises');


function hello() {
    console.log("hello! this is my_babel_js_deobfuscator!")
}


function DeObfuscator(out_put_dir, file_path) {
    var name_no_suffix = file_path.match(/.+[\\\/](\w+)(\.js)?/)[1]
    
    this._ast = null
    this._data = null
    // 解析js为AST
    this.parse_to_ast = function (js_file_name) {
        js_file_name = js_file_name || file_path
        try {
            this._data = fs.readFileSync(js_file_name, 'utf-8')
            this._ast = parser.parse(this._data)
            return this
        } catch (error) {
            throw error
        }
    }

    this.gen_code = function () {
        let {code} = generator(this._ast)
        return code
    }

    // 保存ast为file
    this.ast_save_to_file = function (filepath) {
        let {code} = generator(this._ast)
        try {
            fs.writeFileSync(filepath, code, "utf8")
            return this
        } catch (e) {
            throw e
        }
    }
    //
    this.apply_visitor = function (visitor, reload = false) {
        let ast = this._ast
        if (!ast || !visitor) {
            throw "ast && vistor 不能为空！"
        }
        let tmp_file_name = path.resolve('./', "_stage.js")
        traverse(ast, visitor)
        if (reload) {
            this.ast_save_to_file(tmp_file_name)
            return this.parse_to_ast(tmp_file_name)
        }
        return this
    }

    this.common_deobfuscate = function () {
        this
            .apply_visitor(RewriteCommaStmtVisitor())
            .apply_visitor(RewriteConditionalStmtVisitor)
            .apply_visitor(RemoveHexStrVisitor)
            .apply_visitor(RewriteLogicStmtVisitor)
            .apply_visitor(RewriteCommaStmtVisitor())
            .apply_visitor(ConstantFoldingVisitor())
            .apply_visitor(RewriteSingleStmtToBlockStmtVisitor)
    }

    this.load_checkpoint = function (step) {
        this.parse_to_ast(out_put_dir + name_no_suffix + "_" + step + ".js")
    }
    
    this.save_checkpoint = function (step) {
        this.ast_save_to_file(out_put_dir + name_no_suffix + "_" + step + ".js")
    }
}


function val_to_literal_exp_node(v) {
    if (typeof (v) == "string") {
        return t.StringLiteral(v)
    } else if (typeof (v) == "number") {
        return t.NumericLiteral(v)
    } else if (v === undefined) {
        return t.identifier("undefined")
    }
    else {
        try {
            return template.ast(JSON.stringify(v))
        } catch (e) {
            throw e
        }
    }
}

/**
 * node array 转 array，主要是 arguments
 * @param nodes
 * @returns {*[]}
 */
function literal_node_array_to_array(nodes) {
    var ret = []
    for (let i = 0; i < nodes.length; i++) {
        let en = nodes[i]
        if (t.isStringLiteral(en) || t.isNumericLiteral(en)) {
            ret.push(en.value)
        } else {
            throw Error("数组包含非常量！")
        }
    }
    return ret
}

function _replace_with_literal(path, val) {
    // let exp_str = JSON.stringify(val)
    // let e_ast = parser.parse(exp_str)
    // let n = e_ast.program.body[0]
    let n = val_to_literal_exp_node(val)
    path.replaceWith(n)
}

/*
判断数组是否都是常量值
 */
function is_array_literal(node) {
    if (!t.isArrayExpression(node)) {
        throw Error("不是数组！")
    }
    for (let i = 0; i < node.elements.length; i++) {
        let en = node.elements[i]
        if (t.isStringLiteral(en) || t.isNumericLiteral(en)) {
            continue
        } else {
            return false
        }
    }
    return true
}

// 判断节点是否是常量
function is_literal_node(node) {
    if (t.isStringLiteral(node)) {
        return true
    }
    else if (t.isNumericLiteral(node)) {
        return true
    }
    else if (t.isNullLiteral(node)) {
        return true
    }
    else if (t.isBooleanLiteral(node)) {
        return true
    }
    else if (t.isArrayExpression(node)) {
        return is_array_literal(node)
    }
    else if (t.isIdentifier(node)) {
        return node.name == "undefined"
    }
    else if (t.isIdentifier(node)) {
        return node.name == "NaN"
    }
    else if (t.isIdentifier(node)) {
        return node.name == "Infinity"
    }
}

function literal_node_to_bool(node) {
    let {code} = generator(node)
    let r = eval("!!" + code)
    return r
}

function get_literal_node_value_to_number(node) {
    if (t.isBooleanLiteral(node)) {
        if (node.value == true) {
            return 1
        } else {
            return 0
        }
    } else if (t.isNumericLiteral(node)) {
        return node.value
    } else if (t.isStringLiteral(node)) {
        return parseFloat(node.value)
    }
}

/*
往外层搜索节点
 */
function up_search(path, t) {
    var p = path
    while (p.context.parentPath) {
        let ppath = p.context.parentPath
        let pnode = ppath.node
        if (pnode.type === t) {
            return ppath
        } else {
            p = ppath
        }
    }
    return
}

/*
是否是单独一个 return 的函数
 */
function is_single_return_function(node) {
    if (t.isFunctionExpression(node)) {
        let body = node.body.body
        if (body.length == 1 && t.isReturnStatement(body[0])) {
            return true
        }
    }
    return false
}


function remap_id_agument(arg, declare_arguments, real_aguments) {
    var ret = []
    for (let i= 0; i < declare_arguments.length; i++) {
        if (declare_arguments[i].name == arg.name) {
            return real_aguments[i]
        }
    }
    return arg
}


/*
转发调用到实际的语句，比如
A["mVhfT"] = function (H, I, J) {
      return H(I, J);
};
转发 B["mVhfT"](h, "This web property is not accessible via this address.", B.VaRgt) 到实际的调用
--> h("This web property is not accessible via this address.", B.VaRgt)
 */
function recall_single_exp_stml_with_arguments(exp, declare_arguments, real_aguments) {
    if (t.isBinaryExpression(exp)) {
        // 一个  二元表达式
        return t.binaryExpression(exp.operator, real_aguments[0], real_aguments[1])
    } else if (t.isCallExpression(exp)) {
        let callee
        // 检查 caller 是不是参数之一
        callee = remap_id_agument(exp.callee, declare_arguments, real_aguments)
        let args = exp.arguments.map(x => remap_id_agument(x, declare_arguments, real_aguments))
        return t.callExpression(callee, args)
    } else if (t.isLogicalExpression(exp)) {
        return t.logicalExpression(exp.operator, real_aguments[0], real_aguments[1])
    }
    else {
        throw Error("不支持！")
    }
}

// 两个节点比较，只比较名字
function compare_node(a, b) {
    // id 的情况
    if (t.isIdentifier(a) && t.isIdentifier(b) && a.name === b.name) {
        return true
    }
    else if (t.isStringLiteral(a) && t.isStringLiteral(b)) {
        return a.value == b.value
    }
    // 属性的情况  xxx['xxx']
    else if (t.isMemberExpression(a) && t.isMemberExpression(b)) {
        return compare_node(a.object, b.object) && compare_node(a.property, b.property)
    } else {
        return a == b
    }
}




/*
常量折叠
 */
ConstantFoldingVisitor = function() {
    function _replace_to_boolean (path, bval) {
        path.replaceWith(t.BooleanLiteral(bval));
    }

    function _could_eval (node) {
        if (t.isBooleanLiteral(node)
            || t.isNumericLiteral(node)
            || t.isStringLiteral(node)
            || (t.isArrayExpression(node) && is_array_literal(node))
            || (t.isIdentifier(node) && node.name == "undefined")
            || (t.isIdentifier(node) && node.name == "NaN")
            || (t.isIdentifier(node) && node.name == "Infinity")
            // 空对象
            || (t.isObjectExpression(node) && node.properties.length == 0)
        ) {
            return true
        }
        return false
    }

    function _folding_boolean (path, re_enter = false) {
        if (path.node.operator == "!") {
            if (path.node.argument.type == "NumericLiteral") {
                return this._replace_to_boolean(path, path.node.argument.value == 0 ? true : false)
            } else if (path.node.argument.type == "UnaryExpression") {
                // 先解析子表达式
                if (!re_enter) {
                    let argument_path = path.get("argument")
                    this._folding_boolean(argument_path)
                    // 然后重新解析一遍当前基点
                    return this._folding_boolean(path, true)
                }
            } else if (path.node.argument.type == "ArrayExpression" && path.node.argument.elements.length == 0) {
                // ![] = false
                return this._replace_to_boolean(path, false)
            } else if (path.node.argument.type == "BooleanLiteral") {
                return this._replace_to_boolean(path, !path.node.argument.value)
            } else if (t.isObjectExpression(path.node.argument) && path.node.argument.properties.length == 0) {
                // !{} = false
                return this._replace_to_boolean(path, false)
            }
        }
    }

    function _folding_literal_opetate(path) {
        let node = path.node
        // 常量的操作
        if (t.isLiteral(node.callee.object)) {
            // 属性操作
            // b = 'error code: 1020{/cdn-cgi/challenge-platform/{reload{fromCharCode{function{dsqnx{PAtAi{Gzvgi{alert{QauXZ{yKSzg{pmppB{ZfKqN{value{lYPCE{ffs{TLtIS{getUTCFullYear{href{BVRcd{Khtml Ms O Moz Webkit{smMUW{VXnXc{uKaeL{OvrNC{test{setRequestHeader{cGgAk{apply{Please click here to continue: {IsQgV{input{ZwuUn{color{0|4|3|2|1{prog{This browser is not supported.{ZkOTD{location-mismatch-warning{ePdhT{VifLt{_cf_chl_hload{boolean{oeZfm{QUdPf{borderImage{jBeVO{njJnE{ZzZmu{rEhVu{bTfnj{dfzAT{MpNyA{chCAS{cvKsT{protb{PCiEU{ontimeout{sVlFc{head{touchstart{qCunS{ipiFU{challenge-form{MktpO{GpyDK{neBkj{qLRjJ{JSON.stringify{dBVzN{CuXdh{IvykL{#trk_jschal_js{ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/={inAsS{OytvK{Phmxb{gWqvx{nGQNp{szoXr{izGFmIUNIglu{Eexgd{atob{lkNui{[object Array]{PjVNs{MIrxZ{ofXNe{HBsPq{owGAK{=; Max-Age=-99999999;{hprwY{fRRXU{5|3|2|0|1|4{DgmgT{MQIbG{XVQPP{click{FKuzj{nmVLh{join{ECgkT{nCXXF{split{jiHqd{vQOcd{tFZfz{push{black{substring{submit{skEic{tnRfI{MfQED{cached-challenge-warning{toUpperCase{ArMYf{status{QeGiK{This challenge page was accidentally cached by an intermediary and is no longer available.{KjbjJ{kfmWz{MNgRr{toJSON{wOpwc{bVkUc{AdzCh{wmhBl{SQtrE{location{DjHeK{cLt{getUTCMonth{zubMw{readystatechange{pYgEo{getUTCSeconds{hJoCS{hostname{ORxWb{cotKa{RZMkO{vfyVa{JSON.parse{cf-spinner-allow-5-secs{qYjXH{assign{type{ovyrN{IRoxu{script error{VRJTB{TcgGe{className{navigator{PnNft{rjmAW{prototype{tVGEm{createElement{ZHaDZ{iKGmq{cf-content{njsUM{PPzKY{&#x60A8;&#x7684;&#x6D4F;&#x89C8;&#x5668;&#x5DF2;&#x7ECF;&#x8FC7;&#x65F6;&#x4E86;&#xFF01; &#x66F4;&#x65B0;&#x60A8;&#x7684;&#x6D4F;&#x89C8;&#x5668;&#x4EE5;&#x6B63;&#x786E;&#x67E5;&#x770B;&#x672C;&#x7F51;&#x7AD9;&#x3002;{wtzCS{eEGXv{KzKBl{cursor{;path=/{readyState{YaUSm{Content-type{AWfBM{length{random{IgHNf{nGjnu{cRay{jc-content{VUZrG{min{lrxol{rLAZU{hjuHo{URL: {pointermove{&#x8BF7;&#x542F;&#x7528;Cookie&#x5E76;&#x91CD;&#x65B0;&#x52A0;&#x8F7D;&#x9875;&#x9762;&#x3002;{TmQoA{sfdAJ{ZMLTM{CRmxA{RmDdV{FPANX{MlUpI{transform{https://cloudflare.hcaptcha.com/1/api.js?endpoint=https%3A%2F%2Fcloudflare.hcaptcha.com&assethost=https%3A%2F%2Fcf-assets.hcaptcha.com&imghost=https%3A%2F%2Fcf-imgs.hcaptcha.com&{pcEFc{script{GFZuf{string{[[[ERROR]]]:{msg{GlNZR{HEegq{vZxiv{rfqUz{keydown{dsWud{POST{Date{This web property is not accessible via this address.{I am human!{curCk{TodFR{cf_chl_prog{VsOSm{LGTIp{complete{eQyZj{document{JREFE{charAt{xtKId{ubjpt{WPrKG{uzrwx{none{zulEH{jRUkW{SawvR{PhoRe{</p></div>{WuKRQ{owxXH{IXgjC{lMuRW{eBLnm{fHwjZ{_cf_chl_done_ran{yjs{IUoFk{fwtSn{cNounce{span{NcMkG{VIvGS{CZrCO{AsGfj{ugoch{_cf_chl_hlep{application/x-www-form-urlencoded{VHdtr{WVdZv{innerHTML{no-cookie-warning{NtYyd{querySelector{mousemove{OyefE{KKNCT{QCDsH{send{LdJOO{passive{aJIrX{tekqp{style{Proxy{_cf_chl_done{getTime{cf-please-wait{Function{ebEsL{parse{log{HiZSj{MclFO{Bkxuc{OdsYa{CF-Challenge{lbsXp{dnSMh{cookieEnabled{cf_chl_rc_i{lIHVL{getUTCHours{oquOV{<div class="jc-content"><p style="background-color: #de5052; border-color: #521010; color: #fff;" class="jc-alert jc-alert-error">{HSVpa{VeyXo{NtyGj{jkazW{timeout{nYEzw{scckD{QOjJk{Fjgfr{onerror{jXUEg{RTdih{OWpBE{QhzDi{cType{attachEvent{EvyaY{UTnzD{fKzPU{PNWbW{block{appendChild{yqBBc{qPIiw{unVTK{QPHpm{iAJIy{expires={xPYuw{cHash{xoYGD{XruHG{OnsVy{responseText{Dagiw{DzOji{zODNs{0123456789abcdef{NBBix{open{pnPRr{tIEkl{render=explicit&recaptchacompat=off&onload=_cf_chl_hload{REVDm{jBAakGsZDTMu3R7r6UbeNK+cmVtSQ2q9o-xfgL540I8whnzpElJiCHydOYvPF1WX${4|3|5|0|1|2{VSeSo{dkvlL{addEventListener{lehje{ADEki{EAeyN{DOMContentLoaded{indexOf{gcCEe{ZVxsQ{Microsoft.XMLHTTP{gCiBG{GJkMk{xpxPG{&#x8BE5;&#x8D28;&#x8BE2;&#x9875;&#x9762;&#x88AB;&#x610F;&#x5916;&#x7F13;&#x5B58;&#xFF0C;&#x4E0D;&#x518D;&#x53EF;&#x7528;&#x3002;{HgHye{vXWqg{setTime{call{interactive{iKcbb{WsufC{MuByJ{pow{jc-please-wait{_cf_chl_opt{getElementById{mjECx{PbSbi{%E8%AF%B7%E7%82%B9%E5%87%BB%E8%BF%99%E9%87%8C%E7%BB%A7%E7%BB%AD{Ajekp{zZXeT{cf_chl_{display{cRq{aeJzE{TDueE{SKoBu{sendRequest{ActiveXObject{stringify{setTimeout{&#35813;&#32593;&#31449;&#36164;&#28304;&#26080;&#27861;&#36890;&#36807;&#27492;&#22320;&#22336;&#35775;&#38382;&#12290;{null{setAttribute{onreadystatechange{usyBa{kqNPN{cTTimeMs{EoGPa{<div class="cf-content"><p style="background-color: #de5052; border-color: #521010; color: #fff;" class="cf-alert cf-alert-error">{Line: {iseXa{nEuyO{oPaZH{/0.04523654598791894:1654004371:1a57c4cbe368620724103bb1fa73a4a9ba151625f64f0db9485b5fe10d0c8f41/{now{replace{VqeOt{ - {pointerover{FTJjz{uxhXe{_cf_chl_hloaded{EDTAE{ndtKS{4|1|5|2|6|0|3{%2b{XMLHttpRequest{dpMao{jc-spinner-please-wait{tVQBT{YXCip{aioLb{agKmW{vBXLX{XArQI{NTARr{text/javascript{nVJPi{RDqcN{HaSMz{div{lqvjQ{pdxwD{Math{MAuhW{RLpvq{flow/ov{bgZnB{hxbQL{FNzQi{valueOf{maqQu{parseInt{TmFHy{cgduw{ojQSU{XZfvz{<p class="{floor{gXqnj{onclick{ApewA{-alert-error">&#x76ee;&#x524d;&#x82b1;&#x8d39;&#x65f6;&#x95f4;&#x6bd4;&#x9884;&#x671f;&#x65f6;&#x95f4;&#x8981;&#x957f;&#xff0c;&#x5982;&#x679c;&#x8be5;&#x95ee;&#x9898;&#x4ecd;&#x7136;&#x5b58;&#x5728;&#xff0c;&#x8bf7;&#x68c0;&#x67e5;&#x7f51;&#x7edc;&#x8fde;&#x63a5;&#x5e76;&#x91cd;&#x65b0;&#x52a0;&#x8f7d;&#x754c;&#x9762;</p>{<b>Your browser is out of date!</b><br/>Update your browser to view this website correctly. <a href="https://support.cloudflare.com/hc/en-us/articles/200170136#browser-support">More Information.</a>{charCodeAt{innerText{slice{FFKOi{KfmWJ{UZhFC{cfNjU{getUTCDate{Column: {cvId{dYQoD{HnlBR{rCGld{_cf_chl_enter{Biuvw{removeEventListener{cFPWv{rzpHz{qiJVT{fzosV{lsWlT{GfbjP{loaded{KTLcE{ffoei{bxDRc{HZpfE{fyQDp{plHnt{error{_cf_atob{ePWMu{zGCzb{AfRFI{protocol{beacon/ov{AdxEM{crNpN{-spinner-please-wait{console{lastIndex{bxzye{data-translate{0000{gsiWj{rNYwe{GoxXW{hgIPn{cookie{RxXMW{number{ZlLLp{RdbQi{yfRqf{kFsTH{-alert-error">This is taking longer than expected, check your Internet connection and reload the page if the problem persists.</p>{TDqDj{SHA256{nbqcs{object{XJeWP{JkwCH{chC{hasOwnProperty{QPMLK{ljLlc{mOLxW{ejeiS{ZxCcm{NwZvY{toString{getUTCMinutes{WSawM{RdzKU{SncHO{-alert {pointer{OKqZw{RqiZd{dDMYq{toUTCString{Please enable Cookies and reload the page.{UOaGD{_cf_chl_ctx{JSON{getElementsByTagName{GJnYI{Error object: {jc-spinner-allow-5-secs{jwMao{KABfX{chReq{XrbaE{bTvUn{AShbJ'.split('{');
            if (node.callee.type == "MemberExpression") {
                let const_op;
                if (t.isLiteral(node.callee.property)) {
                    const_op = node.callee.property.value
                } else if (t.isIdentifier(node.callee.property)) {
                    let v = node.callee.property.name
                    let accept_op = ["split"]
                    if (accept_op.indexOf(v) != -1) {
                        const_op = v
                    }
                } else{
                    // 不支持
                    return
                }

                // 参数也必须是常量
                for (let i = 0; i < node.arguments.length; i++) {
                    if (!t.isLiteral(node.arguments[i])) {
                        return
                    }
                }
                try {
                    let ret = node.callee.object.value[const_op](node.arguments.map(a => a.value))
                    return _replace_with_literal(path, ret)
                } catch (e) {
                    console.error(path.toString())
                    throw e
                }
            }
        }
    }

    v = {
        _handle_MemberExpression : function(path) {
            let object = path.node.object
            let property = path.node.property

            // 折叠 [][[]]
            if (t.isArrayExpression(object) && object.elements.length == 0
                && t.isArrayExpression(property) && property.elements.length == 0) {
                path.replaceWith(t.Identifier("undefined"))
            }
        },

        MemberExpression: {
            enter(path) {
                v._handle_MemberExpression(path)
            },
            exit(path) {
                v._handle_MemberExpression(path)
            }
        },

        _handle_UnaryExpression: function (path) {

            let operator = path.node.operator
            let argument = path.node.argument

            // 特殊情况 --1 直接执行会报错
            if ((operator == "-") && t.isNumericLiteral(argument) && argument.value < 0) {
                path.replaceWith(t.NumericLiteral(-1 * argument.value))
            }
            /*
             折叠二元操作符 !
             当出现这个操作符的时候，说明表达式是一个 布尔表达式，可以把一些常见的表达式优化掉
             */
            else if (["+", "-", "!", "~"].indexOf(operator) != -1 && _could_eval(argument)) {
                // 使用 eval 计算

                try {
                    let {code} = generator(path.node)
                    let r = eval(code)
                    _replace_with_literal(path, r)
                } catch (e) {
                    throw e
                }
            }
        },
        UnaryExpression: {
            enter(path) {
                // let s = path.toString()
                // console.log("enter: ", s)
                v._handle_UnaryExpression(path)
                // console.log("after enter: ", path.toString())
            },
            exit(path) {
                // console.log("exit: ", path.toString())
                v._handle_UnaryExpression(path)
                // console.log("after exit: ", path.toString())
            }
        },

        CallExpression: {
            enter(path) {
                _folding_literal_opetate(path)
            },
            exit(path) {
                _folding_literal_opetate(path)
            }
        },

        _handle_BinaryExpression: function (path) {
            let left = path.node.left
            let operator = path.node.operator
            let right = path.node.right

            // bool 数字 字符串 只包含一个元素的列表 相减 -> number
            // 相加 -> string
            if (_could_eval(left) && _could_eval(right)) {
                // 直接使用 eval 来计算
                let {code} = generator(path.node)
                let r = eval(code)
                _replace_with_literal(path, r)
            }
        },
        BinaryExpression: {
            enter(path) {
                // let s = path.toString()
                // console.log("enter: ", s)
                v._handle_BinaryExpression(path)
                // console.log("after enter: ", path.toString())
            },
            exit(path) {
                // console.log("exit: ", path.toString())
                v._handle_BinaryExpression(path)
                // console.log("after exit: ", path.toString())
            }
        },
        LogicalExpression: {
            enter(path) {
                // let s = path.toString()
                // console.log("enter: ", s)
                v._handle_BinaryExpression(path)
                // console.log("after enter: ", path.toString())
            },
            exit(path) {
                // console.log("exit: ", path.toString())
                v._handle_BinaryExpression(path)
                // console.log("after exit: ", path.toString())
            }
        }
    }
    return v
};

/*
解析16进制格式字符串
    比如
        _0x2fd4f4['\x70\x75\x73\x68'](_0x2fd4f4['\x73\x68\x69\x66\x74']());
    =>
        _0x2fd4f4["push"](_0x2fd4f4["shift"]());

*/
const RemoveHexStrVisitor = {
    StringLiteral(path) {
        // path.node.extra.rawValue = JSON.stringify(path.node.value)
        delete path.node.extra
    },
    NumericLiteral(path) {
        delete path.node.extra
    },
}

const RemoveUnreachableBlock = function () {
    function do_if(path) {
        let node = path.node
        let test = node.test
        let consequent = node.consequent
        let alternate = node.alternate

        if (is_literal_node(test)) {
            // 两个分支
            if (consequent && alternate) {
                if (literal_node_to_bool(test)) {
                    path.replaceWith(consequent)
                } else {
                    path.replaceWith(alternate)
                }
            }
            // 只有 if 没有 else
            else {
                if (literal_node_to_bool(test)) {
                    path.replaceWith(consequent)
                } else {
                    path.remove()
                }
            }
        }
    }

    v = {
        IfStatement: {
            enter(path) {
                do_if(path)
            },
            exit(path) {
                do_if(path)
            }
        }
    }
    return v
}



/*
把对字符串的解密操作替换为解密后的结果
 */
const DeferCallToFuncVisitor = function (callee_name, defer, opt = null) {
    if (!opt) {
        // 配置哪种情况启用替换
        opt = {
            "CallExpression": true,
            "MemberExpression": true
        }
    }

    function _callToStr(path) {
        let node = path.node
        if (t.isCallExpression(node) && opt["CallExpression"]) {
            if (t.isIdentifier(node.callee) && callee_name.indexOf(node.callee.name) != -1) {
                // 这里之所以能这么干是因为这个函数真的就只是解密操作而已，没有修改外部的任何变量
                let agrs = node.arguments.map(a => a.value)
                let result = defer.apply(null, agrs)
                try {
                    _replace_with_literal(path, result)
                } catch (e) {
                    console.error(e)
                }
            }
        } else if (t.isMemberExpression(node) && opt["MemberExpression"]) {
            if (t.isIdentifier(node.object) && callee_name.indexOf(node.object.name) != -1) {
                let agrs = node.property.value
                result = defer(agrs)
                try {
                    _replace_with_literal(path, result)
                } catch (e) {
                    console.error(e)
                }

            }

        }
    }

    var visitor = {
        CallExpression(path) {//step1
            _callToStr(path)
        },

        MemberExpression(path) {
            _callToStr(path)
        }
    }
    return visitor
}


/*
把 xxx[yyy](a,b,c) 的调用转发到自定义的函数 xxx(property_name, args)
注意：自定义函数必须返回一个常量
 */
const DeferMemberCallToFuncVisitor = function (object_name, property_list, callback) {
    function do_DeferMemberCallToFuncVisitor(path, object_name, property_list, callback) {
        let node = path.node
        let callee = node.callee
        let arguments = node.arguments

        if (t.isMemberExpression(callee) && t.isIdentifier(callee.object) && callee.object.name === object_name) {
            let property = callee.property
            if (t.isIdentifier(property) && property_list.indexOf(property.name) != -1) {
                let agrs = node.arguments.map(function (a) {
                    if (t.isArrayExpression(a)) {
                        let r = a.elements.map(e => e.value)
                        return r
                    } else {
                        return a.value
                    }
                })
                result = callback(property.name, agrs)
                try {
                    _replace_with_literal(path, result)
                } catch (e) {
                    console.error(e)
                }
            }

        }
    }

    var visitor = {
        CallExpression: {
            enter(path) {
                do_DeferMemberCallToFuncVisitor(path, object_name, property_list, callback)
            },
            exit(path) {
                do_DeferMemberCallToFuncVisitor(path, object_name, property_list, callback)
            }
        }
    }
    return visitor
}


/**
 * 把 while(true) 的循环结构变成平坦结构
 * @param switch_str switch 部分的字符
 * @param order_att 包含顺序的数组
 * @param init_case_value 第一个块的值
 * @constructor
 *
 * 例子
 * a8 = ["0", "6", "14", "9", "1", "4", "2", "3", "12", "11", "10", "7", "8", "13", "5"];
 *
 *     for (a9 = 0; true;) {
 *         switch (a8[a9++]) {
 *             case "0":
 *             case "1"
 *             }
 *     }
 */
RewriteWhileTrueVisitor = function (switch_str, order_att, init_case_value) {
    function doo(path) {
        let node = path.node
        let discriminant = node.discriminant
        let cases = node.cases

        // 判断是否是所需的 switch 块
        if (switch_str) {
            // 使用输入的模式，需要传入顺序数组，以及初始 case 值
        } else {
            let pp = path.parentPath.parentPath
            // 在一个 for 里面
            if (path.listKey == "body" && t.isForStatement(pp)) {
                
            }
        }

        let pre_sibling = path.getPrevSibling()
        // 一个 while 语句，条件为 true，并且其上一条语句是一个 变量声明，第一个变量是一个常量数组
        if (path.inList && t.isBooleanLiteral(node.test) && node.test.value == true
            && t.isVariableDeclaration(pre_sibling)
            && t.isArrayExpression(pre_sibling.get("declarations")[0].container[0].init)) {
            let orderlist = pre_sibling.get("declarations")[0].container[0].init.elements.map(e => parseInt(e.value))
            let switch_stmt = node.body.body[0]

            const runBody = switch_stmt.cases
            let retBody = []
            orderlist.map(targetIdx => {
                let targetBody = runBody[targetIdx].consequent
                if (t.isContinueStatement(targetBody[targetBody.length - 1])) {
                    targetBody.pop()
                }
                retBody = retBody.concat(targetBody)
            })

            path.replaceWithMultiple(retBody)
            pre_sibling.remove()

            let aaa = 1
        }
    }
    v = {
        SwitchStatement : {
            enter(path) {
                doo(path)
            },
            exit(path) {
                doo(path)
            }
        }
    }
    return v
}


/*
把通过 obj["xxx"] 方式调用的功能替换为直接调用功能
var obj = {
    "add": function(a, b) {
        return a + b
    },
    "equal": function(a, b) {
        return a === b
    }
}
var c = obj.add(1,2) // 源码

var c = 1 + 2  // 我们要替换成的

作者：losingyoung
链接：https://juejin.cn/post/6844903886134870030
来源：掘金
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
 */
const RewriteObjFuncVisitor = {
    // 记录解析的函数对象
    _func_objs: {
        // obj 名字
        "idname": {
            // 保存函数的属性名
            "func_name": null
        }
    },
    _get_formal_arg_pos: function (org_args, argname) {
        for (let i = 0; i < org_args.length; i++) {
            if (org_args[i].name == argname) {
                return i
            }
        }
        return -1
    },

    // 先找到定义函数的对象
    VariableDeclarator: {
        enter(path) {
            let node = path.node
            let idname = node.id.name
            if (t.isObjectExpression(node.init)) {
                for (let i = 0; i < node.init.properties.length; i++) {
                    let p = node.init.properties[i]
                    // 全部都是 StringLiteral + function
                    // 函数只有一句 return
                    let func = p.value
                    let pname = p.key.value
                    if (!t.isStringLiteral(p.key) || !t.isFunctionExpression(func)
                        || func.body.body.length != 1
                        || !t.isReturnStatement(func.body.body[0])) {
                        // 不满足要寻找的 obj
                        console.log(idname, "[\"" + p.key.value + "]\"", "is not the obj to found!")
                        return
                    }
                    let ret_stmt = func.body.body[0]
                    if (!RewriteObjFuncVisitor._func_objs.hasOwnProperty(idname)) {
                        RewriteObjFuncVisitor._func_objs[idname] = {}
                    }
                    // 保存函数信息
                    RewriteObjFuncVisitor._func_objs[idname][pname] = func
                }
                console.log("found:", idname)

                /*
                作用域怎么选，这里定义的都是局部变量，所以只要找到其父函数的作用域即可
                 */
                let pf_path = path.getFunctionParent()
                pf_path.traverse({
                    CallExpression(path) {
                        // 找到调用了函数对象的调用处
                        let node = path.node
                        if (t.isMemberExpression(path.node.callee)
                            && path.node.callee.object.name in RewriteObjFuncVisitor._func_objs
                            && t.isStringLiteral(path.node.callee.property)) {
                            let callobj = path.node.callee.object.name
                            let callobj_prop = path.node.callee.property.value
                            let fe = RewriteObjFuncVisitor._func_objs[callobj][callobj_prop]
                            let ret_stmt = fe.body.body[0]
                            let ret_node = ret_stmt.argument
                            // 不能这样简单的替换，函数参数变了，这里是实参
                            // path.replaceWith(ret_stmt.argument)


                            if (t.isBinaryExpression(ret_node)) {
                                console.assert(node.arguments.length == 2)
                                path.replaceWith(t.BinaryExpression(ret_node.operator, node.arguments[0], node.arguments[1]))
                            } else if (t.isCallExpression(ret_node)) {
                                // 找出原函数是把第几个参数作为函数调用
                                let call_arg_name = ret_node.callee.name     // 原函数调用的参数名
                                let call_arg_index = RewriteObjFuncVisitor._get_formal_arg_pos(fe.params, call_arg_name) // 是形参里面第几个参数
                                console.assert(call_arg_index != -1)
                                // 得到实际的参数名
                                let actual_call_arg = node.arguments[call_arg_index]
                                // 构造剩下的参数，得到原参数在形参的位置，然后从当前参数构造即可
                                let actual_args = []
                                ret_node.arguments.map(a => {
                                    let arg_index = RewriteObjFuncVisitor._get_formal_arg_pos(fe.params, a.name)
                                    console.assert(arg_index != -1)
                                    actual_args.push(node.arguments[arg_index])
                                })
                                // 构造一个调用节点
                                path.replaceWith(t.CallExpression(actual_call_arg, actual_args))
                            } else if (t.isLogicalExpression(ret_node)) {
                                console.assert(node.arguments.length == 2)
                                path.replaceWith(t.LogicalExpression(ret_node.operator, node.arguments[0], node.arguments[1]))
                            } else {
                                console.error("here!")
                            }
                        }
                    }
                })

                // 删除函数对象的节点
                path.remove()
            }
        }
    }
}

/*
把形参替换为实参
 */
const ReplaceOutterArgsToActualArgsVisitor = {
    _arguments_actual: {},
    CallExpression(path) {
        if (path.node.arguments.length > 10) {
            let formal_param = path.node.callee.params
            for (let i = 0; i < formal_param.length; i++) {
                ReplaceOutterArgsToActualArgs._arguments_actual[formal_param[i].name] = path.node.arguments[i]
            }
        }
        // 替换参数
        path.get("callee.body").traverse({
            Identifier(path) {
                // if (path.container)
                if (path.node.name in ReplaceOutterArgsToActualArgs._arguments_actual) {
                    let val = ReplaceOutterArgsToActualArgs._arguments_actual[path.node.name]
                    // let literal = template.expression(JSON.stringify(val))()
                    let literal = val
                    path.replaceWith(literal)
                }
            }
        })
    }
}


/*
把 if for 等 body 为单独语句的改成大括号的块结构
 */
const RewriteSingleStmtToBlockStmtVisitor = {
    IfStatement(path) {
        let consequent = path.node.consequent
        if (!t.isBlockStatement(consequent)) {
            let cpath = path.get("consequent")
            cpath.replaceWith(t.blockStatement([consequent]))
        }
        let alternate = path.node.alternate
        if (alternate && !t.isIfStatement(alternate) && !t.isBlockStatement(alternate)) {
            let cpath = path.get("alternate")
            cpath.replaceWith(t.blockStatement([alternate]))
        }
    },
    "ForStatement|ForInStatement"(path) {
        let body = path.node.body
        if (body && !t.isBlockStatement(body)) {
            let cpath = path.get("body")
            cpath.replaceWith(t.blockStatement([body]))
        }
    }
}

/*
重写三元表达式为 if 表达式
 */
const RewriteTernaryOperatorToIfStmtVisitor = {
    _replace_ternary_operator_to_if_stmt(path, expression) {
        path.replaceWith(t.ifStatement(
            expression.test,
            t.blockStatement([t.expressionStatement(expression.consequent)]),
            t.blockStatement([t.expressionStatement(expression.alternate)])
        ))
    },
    ExpressionStatement(path) {
        let expression = path.node.expression
        // console.debug("line:", expression.loc.start, "type:", path.node.type, path.node.expression.type)

        // 暂时只处理这种 test ? a : b 的表达式，一个单纯的三元操作符
        if (t.isConditionalExpression(expression)) {
            RewriteTernaryOperatorToIfStmtVisitor._replace_ternary_operator_to_if_stmt(path, expression)
        }
        // 赋值表达式
        else if (t.isAssignmentExpression(expression) && t.isConditionalExpression(expression.right)) {
            let left = expression.left
            let right = expression.right
            path.replaceWith(t.ifStatement(
                right.test,
                t.blockStatement([t.expressionStatement(t.assignmentExpression(expression.operator, left, right.consequent))]),
                t.blockStatement([t.expressionStatement(t.assignmentExpression(expression.operator, left, right.alternate))])
            ))
        }

    },

    ReturnStatement(path) {
        // return 三元操作符
        let expression = path.node.argument
        if (t.isConditionalExpression(expression)) {
            path.replaceWith(t.ifStatement(
                expression.test,
                t.blockStatement([t.returnStatement(expression.consequent)]),
                t.blockStatement([t.returnStatement(expression.alternate)]),
            ))
        }
    },
}

/*
展开逗号表达式
 */
RewriteCommaStmtVisitor = function () {
    function _safe_exp(exp) {
        // if (t.isCallExpression(exp) && t.isFunctionExpression(exp.callee)) {
        //     // 如果是一个匿名自执行的函数，需要外面包裹一个括号
        //     return t.expressionStatement(exp)
        // }
        // else {
        //     return exp
        // }
        // 改成表达式语句，否则写回js的时候会生成前后粘连的语句导致语法错误
        return t.expressionStatement(exp)
    }

    v = {
        // 指定表达式语句，并且是逗号表达式就是专门的一个 1，2，3 一样的语句，不包括其他 a = (1,2,3) 之类的情况，可以安全的展开
        _do_exp: function (path) {
            let expression = path.node.expression
            if (t.isSequenceExpression(expression)) {
                let new_stmts = []
                for (let i = 0; i < expression.expressions.length; i++) {
                    new_stmts.push(_safe_exp(expression.expressions[i]))
                }
                path.replaceWithMultiple(new_stmts)
            }

            // 不能直接改 AssignmentExpression ，必须是单独的 AssignmentExpression 语句才能改，所以得放到 ExpressionStatement 里面
            if (t.isAssignmentExpression(expression) && t.isSequenceExpression(expression.right)) {
                let new_stmts = []
                let expressions = path.node.expression.right.expressions
                for (let i = 0; i < expressions.length - 1; i++) {
                    new_stmts.push(_safe_exp(expressions[i]))
                }
                // 最后一条是赋值语句
                new_stmts.push(t.AssignmentExpression(expression.operator, expression.left, expressions[expressions.length - 1]))
                path.replaceWithMultiple(new_stmts)
            }
        },
        ExpressionStatement: {
            enter(path) {
                v._do_exp(path)
            },
            exit(path) {
                v._do_exp(path)
            }
        },

        // 展开 if (test) {} test中的逗号表达式，可以放心的提到 if 上面
        _do_if: function (path) {
            let test = path.node.test
            if (t.isSequenceExpression(test)) {
                // let before_stmts = []
                for (let i = 0; i < test.expressions.length - 1; i++) {
                    // 如果是一个匿名自执行的函数，需要外面包裹一个括号
                    path.insertBefore(_safe_exp(test.expressions[i]))
                }
                path.get("test").replaceWith(test.expressions[test.expressions.length - 1])
            }

            // (,,,) && (,,,)
            if (t.isLogicalExpression(test)) {
                if (t.isSequenceExpression(test.left)) {
                    let expressions = test.left.expressions
                    for (let i = 0; i < expressions.length - 1; i++) {
                        path.insertBefore(_safe_exp(expressions[i]))
                    }
                    path.get("test").get("left").replaceWith(expressions[expressions.length - 1])
                }

                if (t.isSequenceExpression(test.right)) {
                    let expressions = test.right.expressions
                    for (let i = 0; i < expressions.length - 1; i++) {
                        path.insertBefore(_safe_exp(expressions[i]))
                    }
                    path.get("test").get("right").replaceWith(expressions[expressions.length - 1])
                }
            }
        },
        IfStatement: {

            enter(path) {
                v._do_if(path)
            },
            exit(path) {
                v._do_if(path)
            }
        },

        // return a,b,c 的形式，可以放心的把 a, b 提到 return 前面
        _do_return : function (path) {
            if (t.isSequenceExpression(path.node.argument)) {
                try {
                    if (path.listKey) {
                        // 在平坦的语句块中
                        let expressions = path.node.argument.expressions
                        for (let i = 0; i < expressions.length - 1; i++) {
                            path.insertBefore(_safe_exp(expressions[i]))
                        }
                        path.get("argument").replaceWith(expressions[expressions.length - 1])
                    } else if (path.key) {
                        // 在某个语句下面， 比如 if (x) return a, b, c
                        let new_stmts = []
                        let expressions = path.node.argument.expressions
                        for (let i = 0; i < expressions.length - 1; i++) {
                            new_stmts.push(_safe_exp(expressions[i]))
                        }
                        new_stmts.push(t.returnStatement(expressions[expressions.length - 1]))
                        path.parentPath.get(path.key).replaceWithMultiple(new_stmts)
                    } else {
                        throw Error("???")
                    }
                } catch (e) {
                    throw e
                }

            }
        },

        ReturnStatement: {
            enter(path) {

                v._do_return(path)
            },
            exit(path) {
                v._do_return(path)
            }

        },

        _do_for: function(path) {
            node = path.node
            if (t.isSequenceExpression(node.init)) {
                expressions = node.init.expressions
                for (let i = 0; i < expressions.length - 1; i++) {
                    // 如果是一个匿名自执行的函数，需要外面包裹一个括号
                    path.insertBefore(_safe_exp(expressions[i]))
                }
                path.get("init").replaceWith(expressions[expressions.length - 1])
            }
        },

        ForStatement: {
            enter(path) {
                v._do_for(path)
            },
            exit(path) {
                v._do_for(path)
            }
        },

        /*
        ("kqfDqyYob", "MsdVjv") === ("kqfDqyYob", "lDwVV")
         */
        _do_binary: function (path) {
            node = path.node
            if (t.isSequenceExpression(node.left)) {
                expressions = node.left.expressions
                // 跳过常量，没什么用
                // 不是常量也可以跳过，没什么用
                path.get("left").replaceWith(expressions[expressions.length - 1])
            }
            if (t.isSequenceExpression(node.right)) {
                expressions = node.right.expressions
                // 跳过常量，没什么用
                // 不是常量也可以跳过，没什么用
                path.get("right").replaceWith(expressions[expressions.length - 1])
            }
        },
        BinaryExpression: {
            enter(path) {
                // console.log("enter: ", path.toString())
                v._do_binary(path)
                // console.log("after enter: ", path.toString())
            },
            exit(path) {
                // console.log("exit: ", path.toString())
                v._do_binary(path)
                // console.log("after exit: ", path.toString())
            }
        }
    }
    return v
}

/**
 * 重写逻辑表达式
 * @type {{LogicalExpression(*)}}
 */
const RewriteLogicStmtVisitor = {
    _do(path) {
        // 重写单独的逻辑表达式，
        let expression = path.node.expression
        // 逻辑表达式，并且右边是逗号运算符 或者 call 表达式
        if (t.isLogicalExpression(expression)) {

            // && (t.isSequenceExpression(expression.right)
            // || t.isCallExpression(expression.right)
            // || t.isConditionalExpression(expression.right))) {

            // 比如 a > b && a,b,c,d
            // ==> if (a>b) {a,b,c,d}
            if (expression.operator == "&&") {
                path.replaceWith(t.ifStatement(
                    expression.left,
                    // t.blockStatement(expression.right.expressions.map(e => t.expressionStatement(e))),
                    t.blockStatement([t.expressionStatement(expression.right)]),
                ))
            }
            // a || b,c ==> if(!a) {b, c}
            else if (expression.operator == "||") {
                path.replaceWith(t.ifStatement(
                    t.unaryExpression("!", expression.left),
                    // t.blockStatement(expression.right.expressions.map(e => t.expressionStatement(e))),
                    t.blockStatement([t.expressionStatement(expression.right)]),
                ))
            }
        }
    },
    ExpressionStatement: {
        enter(path) {
            RewriteLogicStmtVisitor._do(path)
        },
        exit(path) {
            RewriteLogicStmtVisitor._do(path)
        }
    }
}


/**
 * 重写单独的条件表达式语句
 *
 * 比如 a ? b : c --> if (a) {b} else {c}
 */
const RewriteConditionalStmtVisitor = {
    _do(path) {
        // 重写单独的逻辑表达式，
        let expression = path.node.expression
        // 逻辑表达式，并且右边是逗号运算符 或者 call 表达式
        if (t.isConditionalExpression(expression)) {
            let test = expression.test
            let consequent = expression.consequent
            let alternate = expression.alternate

            path.replaceWith(t.ifStatement(
                test,
                t.blockStatement([t.expressionStatement(consequent)]),
                t.blockStatement([t.expressionStatement(alternate)]),
            ))
        }
    },
    ExpressionStatement: {
        enter(path) {
            RewriteConditionalStmtVisitor._do(path)
        },
        exit(path) {
            RewriteConditionalStmtVisitor._do(path)
        }
    }
}


/*
重命名标识符
 */
const RenameIdentifierVisitor = {
    _set_id_map(m) {
        RenameIdentifierVisitor._id_map = m
    },
    Identifier(path) {
        let vd = path.node
        if (vd.name in RenameIdentifierVisitor._id_map) {
            vd.name = RenameIdentifierVisitor._id_map[vd.name]
        }
    }
}

/*
把已知值为常量的变量替换为常量
比如 var rn = {sK: 1, YK: 2, gK: 10, xK: 7, wK: 8, XK: 9, zK: 0, GK: 4, FK: 5, tK: 6, DK: 3}
把 sK -> 1, YK -> 2 。。。
 */
const RenameIdentifierWithLiteral = function (const_map) {
    return {
        Identifier(path) {
            let vd = path.node
            if (vd.name in const_map) {
                let parent = path.parent
                if ((t.isAssignmentExpression(parent) && t.isIdentifier(parent.left) && parent.left.name == vd.name)
                    || (t.isVariableDeclarator(parent) && t.isIdentifier(parent.id) && parent.id.name == vd.name)
                ) {
                    // 跳过
                } else {
                    _replace_with_literal(path, const_map[vd.name])
                }
            }
        }
    }
}


/*
重写 obj[xxx] 为常量
 */
const RewriteMemberExpressionWithLiteral = function (obj_name, const_obj) {
    return {
        MemberExpression(path) {
            let node = path.node
            let object = node.object
            let property = node.property
            try {
                if (t.isIdentifier(object) && object.name === obj_name) {
                    if (t.isNumericLiteral(property) || t.isStringLiteral(property)) {
                        let v = const_obj[property.value]
                        _replace_with_literal(path, v)
                    } else {
                        // console.log("不支持对", obj_name, "取", property)
                    }
                }
            } catch (e) {
                throw e
            }
        }
    }
}

/*
抽取有名字的 lambda 函数
(function hJ() {
})(a, b)
 */
function ExactNamedLambdaFunction(filter_cb, dst_block) {
    let v = {
        CallExpression(path) {
            let node = path.node
            let callee = path.node.callee
            let arguments = path.node.arguments

            if (t.isFunctionExpression(callee)
                && t.isIdentifier(callee.id)
            ) {
                let name = callee.id.name
                let body = callee.body

                // 判断是否需要提取
                if (!filter_cb || !filter_cb(path, node, name)) {
                    return
                }

                if (typeof dst_block === 'number') {
                    let dpath = path
                    for (let i = 0; i < dst_block; i++) {
                        dpath = up_search(dpath, "BlockStatement")
                    }
                    dst_block = dpath.node
                }
                // 添加一个函数声明到目的块里面
                dst_block.body.push(t.functionDeclaration(callee.id, callee.params, callee.body, callee.async))
                // 把当天节点替换为函数调用
                path.replaceWith(t.callExpression(callee.id, arguments,))
            }
        }
    }
    return v
}



/**
 * 合并 CN 的 case 执行流
 */
function find_case(cases, n) {
    var i = 0
    for (i = 0; i < cases.length; i++) {
        let casenode = cases[i]
        // default 没有 test
        if (casenode.test) {
            let case_value = casenode.test.value
            if (case_value === n) {
                return i
            }
        }
    }
    console.warn("没有找到指定的 case！" + n)
}

/*
    返回下一个 case 的值以及赋值这个case的 行数
    [
        next_case_value,
        ass_next_case_pos
            -1 表示没有找到
            -2 表示直接返回
    ]
     */
function _resolve_next_case(case_value, body, switch_var, end_value) {

    for (let i = 0; i < body.length; i++) {
        let node = body[i]
        if (t.isExpressionStatement(node)) {
            let expression = node.expression
            if (t.isAssignmentExpression(expression) && compare_node(switch_var, expression.left)) {
                let right = expression.right
                let operator = expression.operator

                // 计算下一个 case 的值
                if (t.isNumericLiteral(right)) {
                    if (operator === "=") {
                        return [right.value, i]
                    } else if (operator === "-=") {
                        return [case_value -= right.value, i]
                    } else if (operator === "+=") {
                        return [case_value += right.value, i]
                    } else {
                        throw Error("未识别的CN运算！")
                    }
                } else if (t.isStringLiteral(right)) {
                    return [right.value, i]
                } else if (t.isIdentifier(right) && right.name === "undefined") {
                    return [right.value, i]
                } else {
                    throw Error("未识别的CN运算！")
                }
            }
        } else if (t.isReturnStatement(node)) {
            // -2 表示直接 return
            return ["return", -2]
        }
    }
    return [-1, -1]
}


const MergeCaseFlowVisitor = function (case_name, end_value) {

    function _find_cn_assign(body) {
        for (let i = 0; i < body.length; i++) {
            let node = body[i]
            if (t.isExpressionStatement(node)) {
                let expression = node.expression
                if (t.isAssignmentExpression(expression) && t.isIdentifier(expression.left) && expression.left.name == case_name) {
                    return i
                }
            }
        }
    }

    let visitor = {
        _MERGE_CASE_VALUE_MAP: {
            // 合并以后的 CN号，比如 1和2合并了，那当前节点就应该是2了
            // 保存的是后一个 case 块的值，因为后面的块得根据上一个块计算
        },
        _CASE_BODY_MAP: {
            // 保存指定 case 值的 body
        },
        _do_MergeCNCaseFlow(path) {
            _MERGE_CASE_VALUE_MAP = visitor._MERGE_CASE_VALUE_MAP
            _CASE_BODY_MAP = visitor._CASE_BODY_MAP
            while (true) {
                let discriminant = path.node.discriminant
                let cases = path.node.cases
                // case 测试的值是什么，一个 id，或者是一个属性 xxx['xxx']
                let case_var = discriminant

                // 解析每一个块的下一个块，把块拼接起来
                // if (t.isIdentifier(discriminant) && discriminant.name === case_name) {
                {
                    // console.log("find cases", cases.length)
                    let changed = false
                    for (let i = 0; i < cases.length; i++) {
                        let node = cases[i]
                        let consequent = node.consequent
                        let test = node.test
                        let block_body = consequent

                        if (!test) {
                            // 跳过 default
                            continue
                        }

                        let case_now = test.value
                        _CASE_BODY_MAP[case_now] = block_body

                        // CN merge 表示合并以后的下一个 case 值
                        // 由于一次只合并一个块，下一次循环进来时 case 块可能已经不是当前 case的值了，已经合并了其他块进来了
                        // 这时这个 case 值其实已经是已合并块的 case 值
                        let case_value_merged = case_now
                        if (_MERGE_CASE_VALUE_MAP[case_now]) {
                            case_value_merged = _MERGE_CASE_VALUE_MAP[case_now]
                        }
                        // 跳过已经解析到头的
                        if (case_value_merged === end_value || case_value_merged == "return" ) {
                            continue
                        }

                        // 解析下一个 case 的值，以及这句操作的行数
                        let [next_case_value, ass_next_case_pos] = _resolve_next_case(case_value_merged, block_body, case_var, end_value)
                        console.log(case_name, "now", case_now, "merged as ", case_value_merged, "next ->", next_case_value, "next_pos", ass_next_case_pos)
                        _MERGE_CASE_VALUE_MAP[case_now] = next_case_value

                        // 删除 cn 赋值
                        if (ass_next_case_pos != -1 && ass_next_case_pos != -2) {
                            // 不会删除 没有 cn 的或者是 直接 return 的
                            block_body.splice(ass_next_case_pos, 1)
                        }

                        // 合并块
                        if (next_case_value != -1 && ass_next_case_pos != -2 && next_case_value != "return" && next_case_value != end_value) {
                            // 这是一个指向下一个块的块
                            // 删除此节点中的 CN, 把下一个case的语句移过来
                            console.log("合并", case_now, next_case_value)
                            if (_MERGE_CASE_VALUE_MAP[next_case_value]) {
                                // 要合并的 case 是已经合并过其他块的块
                                console.log("set", case_now, "--> ", _MERGE_CASE_VALUE_MAP[next_case_value])
                                _MERGE_CASE_VALUE_MAP[case_now] = _MERGE_CASE_VALUE_MAP[next_case_value]
                            }

                            // 获取下一个 case
                            let next_case_pos = find_case(cases, next_case_value)
                            let next_case
                            if (next_case_pos) {
                                // 从 cases 中删除下一个 case
                                next_case = cases.splice(next_case_pos, 1)[0]
                                next_case = next_case.consequent
                                // 保存下来以防被多次引用
                                if (!_CASE_BODY_MAP[next_case_value]) {
                                    _CASE_BODY_MAP[next_case_value] = next_case
                                }
                            } else {
                                console.warn("可能出现一个 case 块被多个块引用的情况！！！")
                                next_case = _CASE_BODY_MAP[next_case_value]
                            }

                            // console.assert(t.isBlockStatement(next_case[0]))
                            // next_case = next_case[0].body

                            // 删除上一块中的 break 语句
                            for (let i = 0; i < block_body.length; i++) {
                                if (t.isBreakStatement(block_body[i])) {
                                    block_body.splice(i, 1)
                                    break
                                }
                            }

                            // 合并下一个 case 到当前 case
                            for (let i = 0; i < next_case.length; i++) {
                                block_body.push(next_case[i]);
                            }
                            changed = true
                            break
                        } else if (next_case_value == end_value) {
                            // 加上 CN = 1383 以便于在浏览器中调试
                            block_body.splice(-1, 0, t.expressionStatement(t.assignmentExpression("=", t.identifier(case_name), t.numericLiteral(end_value))))
                            console.log(case_name, "--------------------------", case_now, "--> end")
                        } else if (next_case_value == -1) {
                            // 普通块？
                            console.log(case_name, "--------------------------", case_now, "--> end")
                        }
                    }
                    if (changed) {
                        continue
                    }
                }
                break
            }
        },

        SwitchStatement: {
            enter(path) {
                visitor._do_MergeCNCaseFlow(path)
            }
            ,
            exit(path) {
                // MergeCNCaseFlow._do_MergeCNCaseFlow(path)
            }
        }
    }
    return visitor
}



module.exports = {
    hello,
    DeObfuscator,
    // parse_to_ast,
    // ast_save_to_file,
    // apply_visitor,
    // 辅助函数
    is_single_return_function,
    // 转发调用
    recall_single_exp_stml_with_arguments,
    // 
    literal_node_array_to_array: literal_node_array_to_array,

    ConstantFoldingVisitor,
    RemoveHexStrVisitor,
    DeferCallToFuncVisitor,
    DeferMemberCallToFuncVisitor,
    RewriteMemberExpressionWithLiteral,

    // 删除不可达代码
    RemoveUnreachableBlock,
    RewriteWhileTrueVisitor,
    ReplaceOutterArgsToActualArgsVisitor,
    RewriteSingleStmtToBlockStmtVisitor,
    RewriteCommaStmtVisitor,
    RenameIdentifierVisitor,
    RewriteLogicStmtVisitor,
    RewriteTernaryOperatorToIfStmtVisitor,
    RenameIdentifierWithLiteral,
    RewriteConditionalStmtVisitor,

    ExactNamedLambdaFunction,

    // 合并 case 流
    MergeCaseFlowVisitor,
}
