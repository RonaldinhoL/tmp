const path = require("path");
const fs = require('fs')

const parser = require("@babel/parser")
const traverse = require("@babel/traverse").default
const t = require("@babel/types")
const generator = require("@babel/generator").default
const template = require("@babel/template").default;

const bdeobf = require("my_babel_js_deobfuscator")
const {expressionStatement, assignmentExpression, numericLiteral, blockStatement, identifier} = require("@babel/types");
const {call} = require("@babel/traverse/lib/path/context");


// var name = "./bak/v1_20220528.js"
// var name = "./bak/v1_2.js"
// var name = "z:/v1a"
var name = "./bak/js_ch_v1.js"
// var out_put_dir = "G:/opt/openresty/html/nike/s3.nikecdn.com/z5c8VF3R9F/ZY8l/IcqWFI/Guh5Xrrk7Lac/aE0gZA/EW/"

var name_no_suffix = name.match(/.+\/(\w+)(\.js)?/)[1]
var out_put_dir = "./out/"
var step = 0
let deob
var data
var code


/**
 * 搜索前面的加密字符串
 * b = 'xxxx'.split("x")
 * @param js
 */
function seach_b(js) {
    let m = js.match(/if \(b = '(.+)\.split\('(\S)'\)/)
    if (!m) {
        throw Error("没有找到 字符串 b!")
    }
    var b = m[1]
    var sep = m[2]
    return [b, sep]
}

function search_b_shift_param(js) {
    let m = js.match(/d\(\+\+c\);\s+}\(b,\s(\d+)\)/)
    if (!m) {
        throw Error("没有找到 字符串 b!")
    }
    return parseInt(m[1])
}

var shift_b = function (a, c, d) {
    d = function (e) {
        for (; --e; a.push(a.shift())) {
            ;
        }
    };

    d(++c);
    return a
}

var dec_str = function (arr) {
    return function (a, d, e) {
        a = a - 0;
        e = arr[a];
        return e;
    }
};


/*
 去除 {} 混淆
 A = {};
A["AJckO"] = function (H, I) {
  return H > I;
};

A["iZOsC"] = function (H, I) {
  return H | I;
};
 */
const deobf_object = function (ast, js) {

    // 把 A["xxx"] 替换成实际的值
    let v = {
        _OBJ_name: [],
        _OBJ: {},

        _v2: {
            noScope: true,
            _do: function (path) {
                // 跳过赋值语句
                let node = path.node
                if (!t.isAssignmentExpression(path.parent)) {
                    if (v._OBJ_name.includes(path.node.object.name)) {
                        let attr_name = path.node.property.value ? path.node.property.value : path.node.property.name
                        if (attr_name.length !== 5) {
                            return
                        }
                        // 是在 call 里面
                        if (path.key === "callee") {
                            let f = v._OBJ[attr_name]
                            // 单个 return 的函数
                            if (bdeobf.is_single_return_function(f)) {
                                let stmt = f.body.body[0]
                                let exp = stmt.argument
                                let new_exp = bdeobf.recall_single_exp_stml_with_arguments(exp, f.params, path.parent.arguments)
                                if (path.parentPath.container) {
                                    path.parentPath.replaceWith(new_exp)
                                } else {
                                    aaa = 1
                                }
                            }
                            aaa = 1
                        } else {
                            // 不知道为啥有时候 container 为空了
                            try {
                                if (path.container) {
                                    path.replaceWith(v._OBJ[attr_name])
                                }
                            } catch (e) {
                                console.error(e)
                            }
                        }
                    }
                    aaa = 1
                }
            },
            MemberExpression: {
                enter(path) {
                    v._v2._do(path)
                },
                exit(path) {
                    v._v2._do(path)
                }
            }
        },

        _do: function (path) {
            let node = path.node
            let body = node.body.body
            v._OBJ = {}
            v._OBJ_name = []
            if (body.length > 2) {
                let stmt = body[0]
                if (t.isExpressionStatement(stmt) && t.isAssignmentExpression(stmt.expression)) {
                    let left = stmt.expression.left
                    let right = stmt.expression.right
                    let idx = 0
                    if (t.isObjectExpression(right) && right.properties.length === 0) {
                        // 第一行是 A = {}
                        v._OBJ_name.push(left.name)
                        idx += 1
                    } else if (t.isMemberExpression(left) && left.property.value.length === 5) {
                        // 第一行就是 A['xxxxx'] = xxx
                        v._OBJ_name.push(left.object.name)
                    }

                    if (v._OBJ_name.length > 0) {
                        try {
                            for (let i = idx; i < body.length; i++) {
                                stmt = body[i]
                                if (t.isExpressionStatement(stmt) && t.isMemberExpression(stmt.expression.left) && v._OBJ_name.includes(stmt.expression.left.object.name)) {
                                    left = stmt.expression.left
                                    let attr_name = left.property.value ? left.property.value : left.property.name
                                    right = stmt.expression.right
                                    v._OBJ[attr_name] = right
                                } else if (t.isAssignmentExpression(stmt.expression) && stmt.expression.right.name == v._OBJ_name[0]) {
                                    v._OBJ_name.push(stmt.expression.left.name)
                                }
                                stmt = stmt
                            }
                        } catch (e) {
                            throw e
                        }
                        traverse(node, v._v2,)
                    }
                }
            }
        },

        FunctionExpression: {
            enter(path) {
                v._do(path)
            },
            exit(path) {
                // MergeCNCaseFlow._do_MergeCNCaseFlow(path)
            }
        },

        FunctionDeclaration: {
            enter(path) {
                v._do(path)
            },
            exit(path) {
                // MergeCNCaseFlow._do_MergeCNCaseFlow(path)
            }
        },
    }
    traverse(ast, v)
}


try {

    // deob = new bdeobf.DeObfuscator().parse_to_ast(path.resolve(__dirname, "demo.js"))

    data = fs.readFileSync(name, 'utf-8')
    deob = new bdeobf.DeObfuscator().parse_to_ast(path.resolve(__dirname, name))
    code = deob.gen_code()
    var [b, sep] = seach_b(code)
    var shift = search_b_shift_param(code)
    b = b.split(sep)
    b = shift_b(b, shift)

    // 解密字符串
    deob.apply_visitor(bdeobf.DeferCallToFuncVisitor("c", dec_str(b)))
    deob.ast_save_to_file(out_put_dir + name_no_suffix + "_" + step + ".js")


    deob = new bdeobf.DeObfuscator().parse_to_ast(out_put_dir + name_no_suffix + "_" + step + ".js")
    deob
        .apply_visitor(bdeobf.RewriteCommaStmtVisitor)
    deobf_object(deob._ast)

    step += 1
    deob.ast_save_to_file(out_put_dir + name_no_suffix + "_" + step + ".js")

    deob = new bdeobf.DeObfuscator().parse_to_ast(out_put_dir + name_no_suffix + "_" + step + ".js")

    deob
        .apply_visitor(bdeobf.RewriteCommaStmtVisitor)
        .apply_visitor(bdeobf.RewriteConditionalStmtVisitor)
        .apply_visitor(bdeobf.RemoveHexStrVisitor)
        .apply_visitor(bdeobf.RewriteLogicStmtVisitor)
        .apply_visitor(bdeobf.RewriteCommaStmtVisitor)
        .apply_visitor(bdeobf.ConstantFoldingVisitor)
        .apply_visitor(bdeobf.RewriteSingleStmtToBlockStmtVisitor)
        //
        .apply_visitor(bdeobf.RewriteCommaStmtVisitor)
        .apply_visitor(bdeobf.RewriteConditionalStmtVisitor)
        .apply_visitor(bdeobf.RemoveHexStrVisitor)
        .apply_visitor(bdeobf.RewriteLogicStmtVisitor)
        .apply_visitor(bdeobf.RewriteCommaStmtVisitor)
        .apply_visitor(bdeobf.ConstantFoldingVisitor)
        .apply_visitor(bdeobf.RewriteSingleStmtToBlockStmtVisitor)
        //
        .apply_visitor(bdeobf.RewriteCommaStmtVisitor)
        .apply_visitor(bdeobf.RewriteConditionalStmtVisitor)
        .apply_visitor(bdeobf.RemoveHexStrVisitor)
        .apply_visitor(bdeobf.RewriteLogicStmtVisitor)
        .apply_visitor(bdeobf.RewriteCommaStmtVisitor)
        .apply_visitor(bdeobf.ConstantFoldingVisitor)
        .apply_visitor(bdeobf.RewriteSingleStmtToBlockStmtVisitor)

    step += 1
    deob.ast_save_to_file(out_put_dir + name_no_suffix + "_" + step + ".js")

    // deob.ast_save_to_file("G:\\opt\\openresty\\html\\nike\\s3.nikecdn.com\\HPAZvebMcxy_9\\nOK3\\aUJuD4RhW4\\f9b7cppb5ck1\\SQgqJ1wMBA\\aAVKZEx\\" + name_no_suffix + ".js")

} catch (e) {
    console.error(e.stack)
    deob.ast_save_to_file(out_put_dir + name_no_suffix + "_" + "err" + ".js")
}


