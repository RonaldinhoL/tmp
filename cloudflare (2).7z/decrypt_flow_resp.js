const path = require("path");
const fs = require('fs')

const parser = require("@babel/parser")
const traverse = require("@babel/traverse").default
const t = require("@babel/types")
const generator = require("@babel/generator").default
const template = require("@babel/template").default;

const bdeobf = require("my_babel_js_deobfuscator")
const {expressionStatement, assignmentExpression, numericLiteral, blockStatement, identifier} = require("@babel/types");
const {call} = require("@babel/traverse/lib/path/context");


// var name = "./bak/flow_resp_capcha_A.js"
var name = "./bak/flow_resp_capcha_B.js"

// var out_put_dir = "G:/opt/openresty/html/nike/s3.nikecdn.com/z5c8VF3R9F/ZY8l/IcqWFI/Guh5Xrrk7Lac/aE0gZA/EW/"

var name_no_suffix = name.match(/.+\/(\w+)(\.js)?/)[1]
var out_put_dir = "./out/"
var step = 0
let deob
var data
var code


var shift_decrypt = function (b, c, f) {
    f = function (g) {
        for (; --g; b.push(b.shift())) {
            ;
        }
    };

    f(++c);
    return b
}

function search_b_shift_param(js) {
    let m = js.match(/d\(\+\+c\);\s+}\(b,\s(\d+)\)/)
    if (!m) {
        throw Error("没有找到 字符串 b!")
    }
    return parseInt(m[1])
}


function decrypt_str() {

    v = {
        AssignmentExpression(path, a, b, c, d) {
            let {left, right, operator} = path.node
            if (t.isIdentifier(left) && operator === "=" && t.isArrayExpression(right) && right.elements.length > 10) {
                let shift_path = path.parentPath.getNextSibling()
                if (t.isExpressionStatement(shift_path) && shift_path.get("expression").isCallExpression()) {
                    let args = shift_path.node.expression.arguments
                    let shift_num = args[1].value
                    console.log("decrypt_str shift_num", shift_num)
                    let arr = eval(path.get("right").toString())
                    arr_dec = shift_decrypt(arr, shift_num)

                    let dec_fun_path = shift_path.getNextSibling()
                    let dec_fun_name = dec_fun_path.node.expression.left.name
                    let b = function (c, d, e) {
                        c = c - 0;
                        e = arr[c];
                        return e;
                    };

                    // 只对下面的语句应用解密
                    dec_fun_path.getAllNextSiblings().map(p => p.traverse(bdeobf.DeferCallToFuncVisitor(dec_fun_name, b)))
                    path.remove()
                    dec_fun_path.remove()
                    shift_path.remove()

                }
                aaa = 1
            }
        }
    }
    return v
}

function decrypt_array() {
    v = {
        VariableDeclarator(path) {
            let {id, init} = path.node
            // 一个 Array
            // var wgxN = new Array();
            // wgxN.push(1);
            // wgxN.push(1.0517894608146916, 4.863408166749182, 1.0691219718491929, 1.2530705671940605, 2.6769181512177354, 0.9942466910158503);
            if (t.isIdentifier(id) && t.isNewExpression(init) && t.isIdentifier(init.callee) && init.callee.name === "Array") {
                let name = id.name
                let push1 = path.parentPath.getNextSibling()
                let args_value = []
                if (t.isExpressionStatement(push1) && t.isCallExpression(push1.node.expression)) {
                    let call_exp = push1.node.expression
                    if (t.isMemberExpression(call_exp.callee) && call_exp.callee.object.name === name) {
                        let args = bdeobf.literal_node_array_to_array(call_exp.arguments)
                        args_value.push(...args)

                        push2 = push1.getNextSibling()
                        let args2 = bdeobf.literal_node_array_to_array(push2.node.expression.arguments)
                        args_value.push(...args2)
                        // 只对下面的语句应用解密
                        push2.getAllNextSiblings().map(p => p.traverse(bdeobf.DeferCallToFuncVisitor(name, b)))
                        path.remove()
                        dec_fun_path.remove()
                        shift_path.remove()
                    }

                }
                aaa = 1
            }
        }
    }
    return v
}

function search_(ast) {
    var _
    v = {
        AssignmentExpression(path) {
            let node = path.node
            if (t.isMemberExpression(node.left) && t.isIdentifier(node.left.object) && node.left.object.name == "window") {
                let {code} = generator(node.right)
                _ = eval(code)
                path.stop()
            }
        }
    }
    traverse(ast, v)
    return _
}

/*
 去除 {} 混淆
 A = {};
A["AJckO"] = function (H, I) {
  return H > I;
};

A["iZOsC"] = function (H, I) {
  return H | I;
};
 */
const deobf_object = function (ast, js) {

    // 把 A["xxx"] 替换成实际的值
    let v = {
        _OBJ_name: [],
        _OBJ: {},

        _v2: {
            noScope: true,
            _do: function (path) {
                // 跳过赋值语句
                let node = path.node
                if (!t.isAssignmentExpression(path.parent)) {
                    if (v._OBJ_name.includes(path.node.object.name)) {
                        let attr_name = path.node.property.value ? path.node.property.value : path.node.property.name
                        if (attr_name.length !== 5) {
                            return
                        }
                        // 是在 call 里面
                        if (path.key === "callee") {
                            let f = v._OBJ[attr_name]
                            // 单个 return 的函数
                            if (bdeobf.is_single_return_function(f)) {
                                let stmt = f.body.body[0]
                                let exp = stmt.argument
                                let new_exp = bdeobf.recall_single_exp_stml_with_arguments(exp, f.params, path.parent.arguments)
                                if (path.parentPath.container) {
                                    path.parentPath.replaceWith(new_exp)
                                } else {
                                    aaa = 1
                                }
                            }
                            aaa = 1
                        } else {
                            // 不知道为啥有时候 container 为空了
                            try {
                                if (path.container) {
                                    path.replaceWith(v._OBJ[attr_name])
                                }
                            } catch (e) {
                                console.error(e)
                            }
                        }
                    }
                    aaa = 1
                }
            },
            MemberExpression: {
                enter(path) {
                    v._v2._do(path)
                },
                exit(path) {
                    v._v2._do(path)
                }
            }
        },

        _do: function (path) {
            let node = path.node
            let body = node.body.body
            v._OBJ = {}
            v._OBJ_name = []
            if (body.length > 2) {
                let stmt = body[0]
                if (t.isExpressionStatement(stmt) && t.isAssignmentExpression(stmt.expression)) {
                    let left = stmt.expression.left
                    let right = stmt.expression.right
                    let idx = 0
                    try {
                        if (t.isObjectExpression(right) && right.properties.length === 0) {
                            // 第一行是 A = {}
                            v._OBJ_name.push(left.name)
                            idx += 1
                        } else if (t.isMemberExpression(left) && t.isStringLiteral(left.property) && left.property.value.length === 5) {
                            // 第一行就是 A['xxxxx'] = xxx
                            v._OBJ_name.push(left.object.name)
                        }
                    } catch (e) {
                        throw e
                    }

                    if (v._OBJ_name.length > 0) {
                        try {
                            for (let i = idx; i < body.length; i++) {
                                stmt = body[i]
                                if (t.isExpressionStatement(stmt) && t.isMemberExpression(stmt.expression.left) && v._OBJ_name.includes(stmt.expression.left.object.name)) {
                                    left = stmt.expression.left
                                    let attr_name = left.property.value ? left.property.value : left.property.name
                                    right = stmt.expression.right
                                    v._OBJ[attr_name] = right
                                } else if (t.isAssignmentExpression(stmt.expression) && stmt.expression.right.name == v._OBJ_name[0]) {
                                    v._OBJ_name.push(stmt.expression.left.name)
                                } else {
                                    // 删除之前的
                                    body.splice(0, i)
                                    break
                                }

                            }
                        } catch (e) {
                            throw e
                        }
                        traverse(node, v._v2,)
                    }
                }
            }
        },

        FunctionExpression: {
            enter(path) {
                v._do(path)
            },
            exit(path) {
                // MergeCNCaseFlow._do_MergeCNCaseFlow(path)
            }
        },

        FunctionDeclaration: {
            enter(path) {
                v._do(path)
            },
            exit(path) {
                // MergeCNCaseFlow._do_MergeCNCaseFlow(path)
            }
        },
    }
    traverse(ast, v)
}




try {
    data = fs.readFileSync(name, 'utf-8')
    deob = new bdeobf.DeObfuscator(out_put_dir, path.resolve(__dirname, name))
    deob.parse_to_ast()
    deob.save_checkpoint(0)

    deob.apply_visitor(bdeobf.RewriteCommaStmtVisitor())

    // 替换最基础的 _ 数组
    var _ = search_(deob._ast)
    deob.apply_visitor(bdeobf.RewriteMemberExpressionWithLiteral("_", _))
    deob.save_checkpoint(1)

    // 常量折叠
    deob.apply_visitor(bdeobf.ConstantFoldingVisitor())
    deob.save_checkpoint(2)

    // 解密 case 中的字符串加密
    // 需要先常量折叠
    deob.apply_visitor(decrypt_str())
    deob.save_checkpoint(3)

    // deob.load_checkpoint(3)
    deobf_object(deob._ast)
    deob.save_checkpoint(4)

    // 合并 case
    deob.apply_visitor(bdeobf.MergeCaseFlowVisitor("flow_resp", "xxxx"))
    deob.save_checkpoint(5)

    // deob.apply_visitor(bdeobf.RewriteWhileTrueVisitor())
    // deob.save_checkpoint(3)

    // deob.common_deobfuscate()
    // deob.save_checkpoint(9)


    // deob.ast_save_to_file("G:\\opt\\openresty\\html\\nike\\s3.nikecdn.com\\HPAZvebMcxy_9\\nOK3\\aUJuD4RhW4\\f9b7cppb5ck1\\SQgqJ1wMBA\\aAVKZEx\\" + name_no_suffix + ".js")

} catch (e) {
    console.error(e.stack)
    deob.ast_save_to_file(out_put_dir + name_no_suffix + "_" + "err" + ".js")
}


